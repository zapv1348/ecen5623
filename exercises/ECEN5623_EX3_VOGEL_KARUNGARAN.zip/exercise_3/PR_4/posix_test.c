#include "posix_mq.c"
//#include "heap_mq.c"



int main()
{
    //heap_mq();
    mq_demo();   

    //delay
    //int i=0;
    //for (i=0;i<50000000;i++);
    ////shutdown();
}
